# 서울 25년 기온 트렌드 분석 (2000~2024)

서울의 일별 기온 9,100여 일치를 분석해 **추세 · 계절성 · 노이즈**를 나누어 보고, "서울은 정말 더워졌는가?"를 데이터로 확인하는 프로젝트입니다.

📄 **결과 리포트: [REPORT.md](REPORT.md)**

## 폴더 구조

```
seoul-temperature-analysis/
├── data/
│   ├── seoul_weather_2000_2024.csv   # 수집한 원본 데이터 (fetch_data.py가 생성)
│   ├── metadata.json                 # 요청 URL, 단위, 라이선스
│   └── README.md                     # 데이터 출처·수집 방법·라이선스
├── images/                           # 분석 그래프 7개 (analysis.py가 생성)
├── results/                          # summary.json, annual_stats.csv
├── fetch_data.py                     # 데이터 수집 스크립트
├── analysis.py                       # 정제 · 분석 · 시각화 · REPORT.md 생성
├── dashboard.py                      # (보너스) Streamlit 대시보드
├── REPORT.md                         # 분석 리포트
└── requirements.txt
```

## 실행 방법 (Python 3.10 이상)

**Windows PowerShell**
```powershell
python -m pip install --user -r requirements.txt
python fetch_data.py
python analysis.py
python -m streamlit run dashboard.py      # (보너스) 대시보드
```

**macOS / Linux**
```bash
python3 -m pip install -r requirements.txt
python3 fetch_data.py
python3 analysis.py
python3 -m streamlit run dashboard.py
```

| 순서 | 명령 | 결과 |
|---|---|---|
| 1 | `fetch_data.py` | Open-Meteo API에서 서울 일별 기온을 받아 `data/`에 CSV로 저장 |
| 2 | `analysis.py` | 정제 → 시계열 분석 → `images/` 그래프 7개 → `REPORT.md` 생성 |
| 3 | `dashboard.py` | 브라우저(localhost:8501)에서 기간·월·기준을 바꿔 가며 탐색 |

`fetch_data.py`가 네트워크 문제로 실패하면, 화면에 나온 URL을 브라우저에 붙여 넣으세요. 나온 내용을 `data/open_meteo_raw.json`으로 저장하고 다시 실행하면 됩니다.

## 과제 요구사항 대응

| 요구사항 | 구현 |
|---|---|
| 시계열 데이터 100개 이상 + 출처·기간 명시 | 9,132일, Open-Meteo(ERA5), 2000-01-01~2024-12-31 |
| 분석 질문 3개 이상 | 4개 (추세 / 월별 차이 / 극단 기온일 / 변동성) |
| 기본 정보·결측치·이상치 처리 | 중복 제거, 날짜 재정렬, 물리 범위 검사, 3일 이하 공백만 보간, ±4σ 표시 |
| 시계열 기법 2가지 이상 | 이동평균(30/365일), 전일 대비 변화량, 구간별 통계, 월별 변동성, 연도별 집계+선형 추세 |
| 시각화 2개 이상 (권장 3개) | 7개 |
| 인사이트 3개 이상 (관찰/해석 구분) | 4개, 각각 관찰(Fact) / 원인 가설(Why) / 행동(Action) |
| 재현성 | `requirements.txt`, 실행 명령, 데이터 출처·라이선스 문구 |
| AI 사용 로그 | REPORT.md 7장 |
| 보너스: 대시보드 | `dashboard.py` (Streamlit) |
| 보너스: 분해·예측 | 시계열 분해 그래프, 베이스라인 예측 4종 비교 |

## 데이터 출처 및 라이선스

- Weather data by [Open-Meteo.com](https://open-meteo.com/), licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
- Generated using Copernicus Climate Change Service information (ERA5 reanalysis)
- Open-Meteo 무료 API는 비상업적 용도로만 사용할 수 있습니다.
